Project screenshots uploaded from admin go here.
